<center><br><br><br><br><br><br><br><br>
    <img src="assets/images/gunadarma.png" width="200px height=" 200px" /> <br>
    <font Size="6" face="Helvetica">Data Mahasiswa Kelas 3KA09</font> <br>
    <font Size="6">Universitas Gunadarma</font>
</center>